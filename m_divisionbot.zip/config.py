telegram_token = '310342887:AAG-6Mllj90jvxth8tw6AhD7j8Pyy2KgQZw'
botan_token = 'cb0a28cf-ce2c-4847-9536-56c4c149345c'

